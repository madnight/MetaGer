<?php

return [
    "plugin.1"	=>	"Wussten Sie, dass Ihr :browser MetaGer als Standardsuchmaschine verwenden kann?",
    "plugin.2"	=>	"Zeig mir wie test"
];
