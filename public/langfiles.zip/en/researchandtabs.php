<?php

return [
    "plugin.1"	=>	"Did you know, that your :browser can use MetaGer as its default search engine? qwe",
    "plugin.2"	=>	"Show me how"
];
