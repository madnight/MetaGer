<?php

return [
    "plugin.1"	=>	"¿Sabía usted que su  :browser puede usar MetaGer por defecto?",
    "plugin.2"	=>	"Mostrarme como asdasd"
];
