<?php

return [
    "plugin.1"	=>	"teast",
    "plugin.2"	=>	"Montre-moi comment"
];
